# API Reservas v0.1

Base: `/reservas/v0.1` (en ALQUIMIA staging demo: `/demo/reservas/v0.1`).

| Método | Ruta | Descripción |
|--------|------|-------------|
| GET | `/health` | Estado del módulo |
| GET | `/services` | Servicios activos del tenant |
| POST | `/services` | Alta servicio (admin) |
| GET | `/resources` | Recursos |
| POST | `/resources` | Alta recurso (admin) |
| POST | `/schedules` | Horario semanal de un recurso |
| GET | `/availability` | Query: `resource_id`, `service_id`, `from`, `to` (ISO) |
| POST | `/bookings` | Crear reserva (RPC anti-solapamiento) |
| GET | `/bookings/:id` | Detalle |
| POST | `/bookings/:id/cancel` | Cancelar |

Errores: `409 SLOT_CONFLICT`, `400 VALIDATION`, `403 FORBIDDEN`.
