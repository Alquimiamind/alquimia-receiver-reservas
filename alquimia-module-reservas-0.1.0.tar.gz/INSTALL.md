# Instalación — Reservas v0.1

## Variables

| Variable | Uso |
|----------|-----|
| `RESERVAS_TENANT_ID` | Aislamiento de datos (UUID de proyecto o slug de negocio) |
| `RESERVAS_DEFAULT_TIMEZONE` | IANA, ej. `America/Argentina/Buenos_Aires` |
| `SUPABASE_URL` / `SUPABASE_SERVICE_ROLE_KEY` | Acceso PostgREST (o reemplazar por adaptador propio) |

No incluir secretos en el paquete ni en el manifiesto.

## Pasos

1. Ejecutar migración SQL del paquete.
2. Crear servicios, recursos y horarios vía API admin o SQL seed.
3. Exponer rutas HTTP del módulo en el host del negocio.
4. Configurar autenticación **en el host** (el módulo no usa auth de ALQUIMIA).

## Integridad del artefacto

Comparar `artifact_sha256` en fábrica con `dist/package-manifest.json` del paquete descargado.
