# @alquimia/module-reservas v0.1.0

Módulo portable de reservas y turnos. Sin dependencias de la consola ALQUIMIA.

## Instalación

1. Aplicar `migrations/001_mod_reservas_schema.sql` en PostgreSQL del negocio.
2. `npm install @alquimia/module-reservas` (o copiar el paquete desde el artefacto de fábrica).
3. Configurar variables: `SUPABASE_URL` + `SUPABASE_SERVICE_ROLE_KEY` (o adaptador Postgres propio).
4. Montar `createReservasRouter({ supabaseUrl, serviceRoleKey, config: { tenantId, defaultTimezone }, allowAdminWrites })` en su API.

## Actualización

Aplicar migraciones nuevas en orden. No eliminar columnas en caliente sin backup.

## Reversión

Mantener datos en `mod_reservas_*`; desmontar rutas del módulo. Rollback SQL documentado por versión en `migrations/`.

Ver `INSTALL.md` y `API.md`.
