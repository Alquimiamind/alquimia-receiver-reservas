/**
 * Instalador portable — verifica manifiesto y aplica migraciones en PostgreSQL aislado.
 * Uso: DATABASE_URL=... PACKAGE_ROOT=... EXPECTED_ARTIFACT_SHA256=... node install/install.mjs
 */
import { createHash } from "node:crypto";
import { createReadStream, existsSync } from "node:fs";
import { readFile, readdir } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import pg from "pg";

const __dir = path.dirname(fileURLToPath(import.meta.url));
const packageRoot = process.env.PACKAGE_ROOT ?? path.join(__dir, "..");

const TEXT_HASH = /\.(sql|mjs|md|json|ts|js|d\.ts)$/i;

async function sha256File(filePath) {
  const hash = createHash("sha256");
  if (TEXT_HASH.test(filePath)) {
    const raw = await readFile(filePath);
    hash.update(Buffer.from(raw.toString("utf8").replace(/\r\n/g, "\n"), "utf8"));
    return hash.digest("hex");
  }
  await new Promise((resolve, reject) => {
    createReadStream(filePath).on("data", (c) => hash.update(c)).on("end", resolve).on("error", reject);
  });
  return hash.digest("hex");
}

async function verifyManifest() {
  const manifestCandidates = [
    path.join(packageRoot, "dist", "package-manifest.json"),
    path.join(packageRoot, "package-manifest.json"),
  ];
  const manifestPath = manifestCandidates.find((p) => existsSync(p));
  if (!manifestPath) {
    throw new Error("INTEGRITY_FAIL:missing_manifest");
  }
  const manifest = JSON.parse(await readFile(manifestPath, "utf8"));
  for (const entry of manifest.files) {
    const abs = path.join(packageRoot, entry.path);
    const digest = await sha256File(abs);
    if (digest !== entry.sha256) {
      throw new Error(`INTEGRITY_FAIL:${entry.path}`);
    }
  }
  const aggregate = createHash("sha256");
  aggregate.update(JSON.stringify(manifest.files));
  const computed = aggregate.digest("hex");
  if (computed !== manifest.artifact_sha256) {
    throw new Error("INTEGRITY_FAIL:artifact_aggregate");
  }
  const expected = process.env.EXPECTED_ARTIFACT_SHA256?.trim();
  if (expected && expected !== manifest.artifact_sha256) {
    throw new Error("INTEGRITY_FAIL:expected_sha_mismatch");
  }
  return manifest;
}

async function applyMigrations(client) {
  const migDir = path.join(packageRoot, "migrations");
  const files = (await readdir(migDir)).filter((f) => f.endsWith(".sql")).sort();
  for (const file of files) {
    const sql = await readFile(path.join(migDir, file), "utf8");
    await client.query(sql);
  }
}

async function main() {
  const databaseUrl = process.env.DATABASE_URL?.trim();
  if (!databaseUrl) {
    console.error("INSTALL_FAIL:missing_DATABASE_URL");
    process.exit(1);
  }
  const manifest = await verifyManifest();
  const client = new pg.Client({ connectionString: databaseUrl });
  await client.connect();
  try {
    await applyMigrations(client);
    console.log(`INSTALL_OK:version=${manifest.version} artifact=${manifest.artifact_sha256}`);
  } finally {
    await client.end();
  }
}

main().catch((err) => {
  console.error("INSTALL_FAIL", err.message);
  process.exit(1);
});
