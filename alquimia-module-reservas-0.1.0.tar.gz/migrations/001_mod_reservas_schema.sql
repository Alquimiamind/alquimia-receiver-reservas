-- Portable schema @alquimia/module-reservas v0.1.0 (idempotente)

create table if not exists public.mod_reservas_services (
  id uuid primary key default gen_random_uuid(),
  tenant_id text not null,
  name text not null,
  description text not null default '',
  duration_minutes int not null check (duration_minutes > 0 and duration_minutes <= 480),
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.mod_reservas_resources (
  id uuid primary key default gen_random_uuid(),
  tenant_id text not null,
  name text not null,
  description text not null default '',
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.mod_reservas_schedules (
  id uuid primary key default gen_random_uuid(),
  tenant_id text not null,
  resource_id uuid not null references public.mod_reservas_resources (id) on delete cascade,
  day_of_week smallint not null check (day_of_week between 0 and 6),
  start_local time not null,
  end_local time not null,
  timezone text not null default 'UTC',
  check (end_local > start_local)
);

create table if not exists public.mod_reservas_bookings (
  id uuid primary key default gen_random_uuid(),
  tenant_id text not null,
  resource_id uuid not null references public.mod_reservas_resources (id) on delete restrict,
  service_id uuid not null references public.mod_reservas_services (id) on delete restrict,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  status text not null default 'confirmed' check (status in ('confirmed', 'cancelled')),
  customer_name text not null,
  customer_contact text,
  created_at timestamptz not null default now(),
  check (ends_at > starts_at)
);

create index if not exists mod_reservas_services_tenant_idx on public.mod_reservas_services (tenant_id);
create index if not exists mod_reservas_resources_tenant_idx on public.mod_reservas_resources (tenant_id);
create index if not exists mod_reservas_bookings_tenant_resource_idx
  on public.mod_reservas_bookings (tenant_id, resource_id, starts_at)
  where status = 'confirmed';

create or replace function public.mod_reservas_create_booking(
  p_tenant_id text,
  p_resource_id uuid,
  p_service_id uuid,
  p_starts_at timestamptz,
  p_customer_name text,
  p_customer_contact text default null
) returns uuid
language plpgsql
as $$
declare
  v_duration int;
  v_ends_at timestamptz;
  v_id uuid;
begin
  if p_customer_name is null or length(trim(p_customer_name)) < 2 then
    raise exception 'INVALID_CUSTOMER';
  end if;

  select s.duration_minutes into v_duration
  from public.mod_reservas_services s
  where s.id = p_service_id and s.tenant_id = p_tenant_id and s.active = true;

  if v_duration is null then
    raise exception 'SERVICE_NOT_FOUND';
  end if;

  if not exists (
    select 1 from public.mod_reservas_resources r
    where r.id = p_resource_id and r.tenant_id = p_tenant_id and r.active = true
  ) then
    raise exception 'RESOURCE_NOT_FOUND';
  end if;

  v_ends_at := p_starts_at + make_interval(mins => v_duration);

  if exists (
    select 1
    from public.mod_reservas_bookings b
    where b.tenant_id = p_tenant_id
      and b.resource_id = p_resource_id
      and b.status = 'confirmed'
      and tstzrange(b.starts_at, b.ends_at, '[)') && tstzrange(p_starts_at, v_ends_at, '[)')
  ) then
    raise exception 'SLOT_CONFLICT';
  end if;

  insert into public.mod_reservas_bookings (
    tenant_id, resource_id, service_id, starts_at, ends_at, status, customer_name, customer_contact
  ) values (
    p_tenant_id, p_resource_id, p_service_id, p_starts_at, v_ends_at, 'confirmed',
    trim(p_customer_name), nullif(trim(p_customer_contact), '')
  )
  returning id into v_id;

  return v_id;
end;
$$;

alter table public.mod_reservas_services enable row level security;
alter table public.mod_reservas_resources enable row level security;
alter table public.mod_reservas_schedules enable row level security;
alter table public.mod_reservas_bookings enable row level security;

-- Roles Supabase; en PostgreSQL aislado del receptor pueden no existir
do $revoke$
begin
  if exists (select 1 from pg_roles where rolname = 'anon') then
    revoke all on table public.mod_reservas_services from anon, authenticated;
    revoke all on table public.mod_reservas_resources from anon, authenticated;
    revoke all on table public.mod_reservas_schedules from anon, authenticated;
    revoke all on table public.mod_reservas_bookings from anon, authenticated;
  end if;
end
$revoke$;
